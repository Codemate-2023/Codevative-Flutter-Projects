//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<jitsi_meet_wrapper/JitsiMeetWrapperPlugin.h>)
#import <jitsi_meet_wrapper/JitsiMeetWrapperPlugin.h>
#else
@import jitsi_meet_wrapper;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [JitsiMeetWrapperPlugin registerWithRegistrar:[registry registrarForPlugin:@"JitsiMeetWrapperPlugin"]];
}

@end
