package com.example.flutter_jitsi_meet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
